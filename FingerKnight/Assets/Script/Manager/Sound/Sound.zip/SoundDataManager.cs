﻿using UnityEngine;
using System.Collections;

public class SoundDataManager{

    private static SoundDataManager m_Instance;
    public static SoundDataManager Instance
    {
        get
        {
            if (m_Instance == null)
            {
                m_Instance = new SoundDataManager();
            }

            return m_Instance;
        }
    }

    private LetterSoundData[] m_LetterSoundList;
    public LetterSoundData[] LetterSoundList
    {
        get
        {
            return m_LetterSoundList;
        }
    }

    public void SetLetterSoundList(LetterSoundData[] letter)
    {
        m_LetterSoundList = letter;
    }

    private BGMData[] m_BGMList;
    public BGMData[] BGMList
    {
        get
        {
            return m_BGMList;
        }
    }

    public void SetBGMList(BGMData[] bgm)
    {
        m_BGMList = bgm;
    }

    private EffectSoundData[] m_EffectSoundList;
    public EffectSoundData[] EffectSoundList
    {
        get
        {
            return m_EffectSoundList;
        }
    }

    public void SetEffectSoundList(EffectSoundData[] effect)
    {
        m_EffectSoundList = effect;
    }

    private ScriptSoundData[] m_ScriptSoundList;
    public ScriptSoundData[] ScriptSoundList
    {
        get
        {
            return m_ScriptSoundList;
        }
    }

    public void SetScriptSoundList(ScriptSoundData[] script)
    {
        m_ScriptSoundList = script;
    }

    private ScriptSoundData[] m_Etiquette_SubList;
    public ScriptSoundData[] Etiquette_SubList
    {
        get
        {
            return m_Etiquette_SubList;
        }
    }

    public void SetEtiquette_SubList(ScriptSoundData[] script)
    {
        m_Etiquette_SubList = script;
    }

    private ScriptSoundData[] m_ETCSoundList;
    public ScriptSoundData[] ETCSoundList
    {
        get
        {
            return m_ETCSoundList;
        }
    }

    public void SetETCSoundList(ScriptSoundData[] etc)
    {
        m_ETCSoundList = etc;
    }

    private ScriptSoundData[] m_OnboardtSoundList;
    public ScriptSoundData[] OnboardSoundList
    {
        get
        {
            return m_OnboardtSoundList;
        }
    }

    public void SetOnboardSoundList(ScriptSoundData[] onboard)
    {
        m_OnboardtSoundList = onboard;
    }
}
