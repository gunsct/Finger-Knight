﻿using UnityEngine;
using System.Collections;

/*
    Name : 유병훈
    Date : 16.10.17
    Contants:
     SoundData Type 정의
    Operations EX:
*/

public static class SoundDataEnum {
    public enum BGM_TYPE {
        INTRO = 0,
        LOGIN = 1,
        MAIN = 2,
        MAIN2 = 3,
        CLOUD = 4,
        CLOUD2 = 5,
        COLORING_STAGE = 6,
        COLORING = 7,
        COLORING_CLEAR = 8,
        DRESSROOM = 9,
        FIREWORK = 10,
        HOLOGRAM = 11,
        REWARD = 12,
        TREASURE = 13,
        TREASURE2 = 14,
        HARP1 = 15,
        HARP2 = 16,
        HARP3 = 17,
        NONE = -1
    }

    public enum EFFECT_TYPE
    {
        CAMERA_BUTTON = 0,
        COLORING_CLICK = 1,
        BUTTON_CLICK = 2,
        INVEN_CLICK = 3,
        LOCKED_BUTTON = 4,
        BUTTON_OUT = 5,
        BUTTON_TOGGLE = 6,
        TREASURE_CORRECT = 7,
        TREASURE_POISON = 8,
        TREASURE_RULRUACTION = 9,
        TREASURE_RULRUINTRO = 10,
        TREASURE_RULRUSTEP = 11,
        TREASURE_SIGHMASIC = 12,
        TREASURE_SILHOUETTE = 13,
        TREASURE_SWIPE = 14,
        TREASURE_WORD = 15,
        TREASURE_WRONG = 16,
        TREASURE_WRONGSUB = 17,
        FIREWORK_INTRO = 18,
        FIREWORK_START = 19,
        FIREWORK_BOMB = 20,
        FIREWORK_BOMB1 = 21,
        FIREWORK_STAR = 22,
        TOUCH_MISS_PREVENT = 23,
        HARP_DO = 24,
        HARP_RE = 25,
        HARP_MI = 26,
        HARP_FA = 27,
        HARP_SOL = 28,
        HARP_RA = 29,
        HARP_SI = 30,
        HARP_DO2 = 31,
        HARP_CHANGE = 32,
        HARP_PICK = 33,
        HOLOGRAM_DROPFLOWER = 34,
        HOLOGRAM_MICTURN = 35,
        HOLOGRAM_OPENDOOR = 36,
        HOLOGRAM_TOUCH = 37,
        CLOUD_BACK = 38,
        CLOUD_DRAGGING = 39,
        MAIN_RULRU_DRAG = 40,
        MAIN_WALKING = 41,
        COLORING_CLEAR = 42,
        COLORING_DO = 43,
        COLORING_RE = 44,
        COLORING_MI = 45,
        COLORING_FA = 46,
        COLORING_SOL = 47,
        COLORING_RA = 48,
        COLORING_SI = 49,
        COLORING_DO1 = 50,
        COLORING_BRUSH = 51,
        COLORING_BRUSH_1 = 52,
        COLORING_BRUSH_2 = 53,
        CLEAR_BGM = 54,
        CLEAR_1 = 55,
        CLEAR_2 = 56,
        CLEAR_3 = 57,
        MAIN_BOX_TOUCH = 58,
        MAIN_BOX_OPEN = 59,
        MAIN_CLOUD_TOUCH = 60,
        REWARD_GAZE_UP = 61,
        TREASURE_INTRO = 62,
        TREASURE_BALLBACK1 = 63,
        TREASURE_BALLBACK2 = 64,
        MAIN_CLOUD_BLOW = 65,
        MAIN_CLOUD_TIMER = 66
    }
    public enum ONBOARD_TYPE {
        INTRO,
        REWARD,
        CLOUD,
        TREASURE,
        FIREWORK,
        HARP,
        COLORING,
        DRESSROOM,
        HOLOGRAM,
        SETTING,
        TREASURE1,
        TREASURE2,
        TREASURE3,
        HOLOGRAM1,
        HOLOGRAM2,
        HOLOGRAM3,
        HOLOGRAM4
    }
    public enum ETC_TYPE {
        LOGO1,
        LOGO2,
        LOGO3,
        HI,
        BYE,
        BOOK,
        BORED,
        REACT,
        APPEAR,
        INTERACTION,
        HERE1,
        HERE2,
        ITEM,
        HAPPY1,
        HAPPY2,
        THANKS,
        BOREDBOOK
    }
        
}
