﻿/*
    Name : 유병훈
    Date : 16.10.17
    Contants:
     JsonData(SoundData) Info 
    Operations EX:
*/

public class SoundData {

    private int m_id;
    public int id {
        get { return m_id; }
    }
    
    private AudioData[] m_audioList;
    public AudioData[] audioList {
        get {
            return m_audioList;
        }
    }

    public void SetId(int id) {
        m_id = id;
    }

    public void SetAudioList(AudioData[] list) {
        m_audioList = list;
    }
}
