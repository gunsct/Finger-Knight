﻿using UnityEngine;
using System.Collections;
using LitJson;

public class JsonParsingManager{
    private static JsonParsingManager m_instance;
    public static JsonParsingManager instance
    {
        get
        {
            if (m_instance == null)
            {
                m_instance = new JsonParsingManager();
            }

            return m_instance;
        }
    }

    private JsonParsingManager()
    {

    }

    public void StartParsing()
    {
        TextAsset haruJoujuDataText = Resources.Load("Json/haru_jouju_data") as TextAsset;
        JsonData harujoujudata = JsonMapper.ToObject(haruJoujuDataText.text);

        JsonData object3DList = harujoujudata["3DList"]["3DObjectList"];
        JsonData JoujuOutfitList = harujoujudata["3DList"]["JoujuOutfitList"];
        JsonData RulruOutfitList = harujoujudata["3DList"]["RulruOutfitList"];
        JsonData CloudOutfitList = harujoujudata["3DList"]["CloudOutfitList"];
        JsonData EffectSoundList = harujoujudata["SoundList"]["EffectList"];

        JsonData ScriptSoundList = harujoujudata["SoundList"]["ScriptList"][0]["Script"];
        JsonData EtiquetteSubList = harujoujudata["SoundList"]["ScriptList"][0]["Etiquette_sub"];
        JsonData ETCScriptSoundList = harujoujudata["SoundList"]["ScriptList"][1]["ETC"];
        JsonData OnboardScriptSoundList = harujoujudata["SoundList"]["ScriptList"][1]["Onboard"];


        JsonData BGMList = harujoujudata["SoundList"]["BGMList"];
        JsonData FireList = harujoujudata["FireList"]["SpecialFireList"];


        JsonData StickerList = harujoujudata["StickerList"];


        /**Object Parsing*/
        Object_3DData[] object3dList = new Object_3DData[object3DList.Count];
        LetterSoundData[] lettersoundList = new LetterSoundData[object3DList.Count];

        for (int i = 0; i < object3DList.Count; i++)
        {
            object3dList[i] = Parsing3Dobject(object3DList[i]);
            lettersoundList[i] = ParsingLetterSound(object3DList[i]);
        }
        ObjectDataManager.Instance.SetObject3DList(object3dList);

        SoundDataManager.Instance.SetLetterSoundList(lettersoundList);

        /**Outfit Parsing*/
        OutfitData[] joujuoutfitList = new OutfitData[JoujuOutfitList.Count];

        for (int i = 0; i < JoujuOutfitList.Count; i++)
        {
            joujuoutfitList[i] = ParsingOutfit(JoujuOutfitList[i]);
        }
        ObjectDataManager.Instance.SetJoujuOutfitList(joujuoutfitList);

        OutfitData[] rulruoutfitList = new OutfitData[RulruOutfitList.Count];

        for (int i = 0; i < RulruOutfitList.Count; i++)
        {
            rulruoutfitList[i] = ParsingOutfit(RulruOutfitList[i]);
        }
        ObjectDataManager.Instance.SetRulruOutfitList(rulruoutfitList);

        OutfitData[] cloudoutfitList = new OutfitData[CloudOutfitList.Count];

        for (int i = 0; i < CloudOutfitList.Count; i++)
        {
            cloudoutfitList[i] = ParsingOutfit(CloudOutfitList[i]);
        }
        ObjectDataManager.Instance.SetCloudOutfitList(cloudoutfitList);

        /**Sound Parsing*/
        EffectSoundData[] effectsoundList = new EffectSoundData[EffectSoundList.Count];

        for (int i = 0; i < EffectSoundList.Count; i++)
        {
            effectsoundList[i] = ParsingEffectSound(EffectSoundList[i]);
        }
        SoundDataManager.Instance.SetEffectSoundList(effectsoundList);


        ScriptSoundData[] scriptsoundList = new ScriptSoundData[ScriptSoundList.Count];

        for (int i = 0; i < ScriptSoundList.Count; i++)
        {
            scriptsoundList[i] = ParsingScriptSound(ScriptSoundList[i]);
        }
        SoundDataManager.Instance.SetScriptSoundList(scriptsoundList);


        ScriptSoundData[] etiquettesubList = new ScriptSoundData[EtiquetteSubList.Count];

        for (int i = 0; i < EtiquetteSubList.Count; i++)
        {
            etiquettesubList[i] = ParsingScriptSound(EtiquetteSubList[i]);
        }
        SoundDataManager.Instance.SetEtiquette_SubList(etiquettesubList);
        

        ScriptSoundData[] ETCsoundList = new ScriptSoundData[ETCScriptSoundList.Count];

        for (int i = 0; i < ETCScriptSoundList.Count; i++)
        {
            ETCsoundList[i] = ParsingScriptSound(ETCScriptSoundList[i]);
        }
        SoundDataManager.Instance.SetETCSoundList(ETCsoundList);
        

        ScriptSoundData[] OnboardsoundList = new ScriptSoundData[OnboardScriptSoundList.Count];

        for (int i = 0; i < OnboardScriptSoundList.Count; i++)
        {
            OnboardsoundList[i] = ParsingScriptSound(OnboardScriptSoundList[i]);
        }
        SoundDataManager.Instance.SetOnboardSoundList(OnboardsoundList);
        

        BGMData[] bgmsoundList = new BGMData[BGMList.Count];

        for (int i = 0; i < BGMList.Count; i++)
        {
            bgmsoundList[i] = ParsingBGMSound(BGMList[i]);
        }
        SoundDataManager.Instance.SetBGMList(bgmsoundList);

        /**FireWork Parsing*/
        FireData[] fireList = new FireData[FireList.Count];
        OutfitData[] OfireList = new OutfitData[FireList.Count];

        for (int i = 0; i < FireList.Count; i++)
        {
            fireList[i] = ParsingFirework(FireList[i]);
            OfireList[i] = ParsingFireToOutfit(FireList[i]);
        }
        FireDataManager.Instance.SetFireList(fireList);
        ObjectDataManager.Instance.SetFireOutfitList(OfireList);


        /**Sticker Parsing*/
        StickerData[] stickerList = new StickerData[StickerList.Count];
        OutfitData[] OstickerList = new OutfitData[StickerList.Count];

        for (int i = 0; i < StickerList.Count; i++)
        {
            stickerList[i] = ParsingSticker(StickerList[i]);
            OstickerList[i] = ParsingStikerToOutfit(StickerList[i]);
        }
        StickerDataManager.Instance.SetStickerList(stickerList);
        ObjectDataManager.Instance.SetStickerOutfitList(OstickerList);
    }

    /// ///////////////////////////////////////////////////////////////////////////

    private Object_3DData Parsing3Dobject(JsonData obj)
    {
        Object_3DData result = new Object_3DData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string resourceObj = obj["Resource"].ToString();
        string resourcebwObj = obj["ResourceBW"].ToString();
        string resourceemptyObj = obj["ResourceEmpty"].ToString();
        string resourceframeObj = obj["ResourceFrame"].ToString();
        string animationObj = obj["Animation"].ToString();
        string animationSoundObj = obj["AnimationSound"].ToString();
        string letterimageObj = obj["LetterImage"].ToString();
        string lettersoundObj = obj["LetterSound"].ToString();
        string treasureiconObj = obj["TreasureIcon"].ToString();
        string treasurecleariconObj = obj["TreasureClearIcon"].ToString();
        string hologramlearningiconObj = obj["HologramLearningIcon"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetResource(resourceObj);
        result.SetResourceBW(resourcebwObj);
        result.SetResourceEmpty(resourceemptyObj);
        result.SetResourceFrame(resourceframeObj);
        result.SetAnimation(animationObj);
        result.SetAnimationSound(animationSoundObj);
        result.SetLetterImage(letterimageObj);
        result.SetLetterSound(lettersoundObj);
        result.SetTreasureIcon(treasureiconObj);
        result.SetTreasureClearIcon(treasurecleariconObj);
        result.SetHologramLearningIcon(hologramlearningiconObj);

        return result;
    }

    private OutfitData ParsingOutfit(JsonData obj)
    {
        OutfitData result = new OutfitData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string resourceObj = obj["Resource"].ToString();
        string iconObj = obj["Icon"].ToString();
        string iconCompleteObj = obj["IconComplete"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetResource(resourceObj);
        result.SetIcon(iconObj);
        result.SetIconComplete(iconCompleteObj);

        return result;
    }

    private LetterSoundData ParsingLetterSound(JsonData obj)
    {
        LetterSoundData result = new LetterSoundData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string pathObj = obj["LetterSound"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetPath(pathObj);

        return result;
    }

    private EffectSoundData ParsingEffectSound(JsonData obj)
    {
        EffectSoundData result = new EffectSoundData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string pathObj = obj["Path"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetPath(pathObj);

        return result;
    }
    private ScriptSoundData ParsingScriptSound(JsonData obj)
    {
        ScriptSoundData result = new ScriptSoundData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string pathObj = obj["Path"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetPath(pathObj);

        return result;
    }

    private BGMData ParsingBGMSound(JsonData obj)
    {
        BGMData result = new BGMData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string pathObj = obj["Path"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetPath(pathObj);

        return result;
    }

    private FireData ParsingFirework(JsonData obj)
    {
        FireData result = new FireData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        JsonData pathObj = obj["Resource"];
        string headObj = obj["Head"].ToString();
        string iconObj = obj["Icon"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetResource(GetStringArray(pathObj));
        result.SetHead(headObj);
        result.SetIcon(iconObj);

        return result;
    }

    private StickerData ParsingSticker(JsonData obj)
    {
        StickerData result = new StickerData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);

        return result;
    }

    private string[] GetStringArray(JsonData listObj)
    {
        string[] result = new string[listObj.Count];

        for (int i = 0; i < listObj.Count; i++)
        {
            JsonData obj = listObj[i];
            result[i] = obj.ToString();
        }

        return result;
    }

    private OutfitData ParsingFireToOutfit(JsonData obj)
    {
        OutfitData result = new OutfitData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string resourceObj = obj["Resource"][0].ToString();
        string iconObj = obj["Icon"].ToString();
        string iconCompleteObj = obj["Icon"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetResource(resourceObj);
        result.SetIcon(iconObj);
        result.SetIconComplete(iconCompleteObj);

        return result;
    }
    private OutfitData ParsingStikerToOutfit(JsonData obj)
    {
        OutfitData result = new OutfitData();

        int idObj = (int)obj["Id"];
        string nameObj = obj["Name"].ToString();
        string resourceObj = obj["Icon"].ToString();
        string iconObj = obj["Icon"].ToString();
        string iconCompleteObj = obj["Icon"].ToString();

        result.SetId(idObj);
        result.SetName(nameObj);
        result.SetResource(resourceObj);
        result.SetIcon(iconObj);
        result.SetIconComplete(iconCompleteObj);

        return result;
    }
}
