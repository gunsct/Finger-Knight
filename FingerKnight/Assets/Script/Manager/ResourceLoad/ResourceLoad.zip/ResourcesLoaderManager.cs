﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ResourcesLoaderManager
{
    private static ResourcesLoaderManager m_instance;
    public static ResourcesLoaderManager instance
    {
        get
        {
            if (m_instance == null)
            {
                m_instance = new ResourcesLoaderManager();
            }

            return m_instance;
        }
    }

    AssetBundleParsingManager m_bundleManager = new AssetBundleParsingManager();

    public GameObject GetJoujuPrefab(GamedataManager.JoujudressEnum JoujuDress)
    {
        GameObject obj = null;
        string resourcePath = null;
        resourcePath = PathData.CHARBUNDLE_PATH + ObjectDataManager.Instance.JoujuOutfitList[(int)JoujuDress].Resource + ".prefab";
        obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.PREFAB, resourcePath) as GameObject;

        if(JoujuDress == GamedataManager.JoujudressEnum.Trans1)
        {
            obj.transform.FindChild("CH_JJ_trans_02").gameObject.SetActive(false);
        }
        else if(JoujuDress == GamedataManager.JoujudressEnum.Trans2)
        {
            obj.transform.FindChild("CH_JJ_trans_02").gameObject.SetActive(true);
        }

        return obj;
    }

    public GameObject GetRulruPrefab(GamedataManager.RulrudressEnum RulruDress)
    {
        GameObject obj = null;
        string resourcePath = null;
        
        resourcePath = PathData.CHARBUNDLE_PATH + ObjectDataManager.Instance.RulruOutfitList[(int)RulruDress].Resource + ".prefab";
        obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.PREFAB, resourcePath) as GameObject;
        

        return obj;
    }
    
    public GameObject GetCloudPrefab(GamedataManager.CloudEnum NowCloud)
    {
        GameObject obj = null;
        string resourcePath = null;

        resourcePath = PathData.CHARBUNDLE_PATH + ObjectDataManager.Instance.CloudOutfitList[(int)NowCloud].Resource + ".prefab";
                
        obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.PREFAB, resourcePath) as GameObject;

        return obj;
    }
    public AudioClip GetWordAudioClip(int listNum) {
        string resourcePath = PathData.ITEMLETTERSOUND_PATH + ObjectDataManager.Instance.Object3DList[(int)listNum].LetterSound + ".mp3";// SoundDataManager.Instance.BGMList[(int)listNum].Path + ".mp3";
        //Debug.Log(resourcePath);
        AudioClip obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.SOUND, resourcePath) as AudioClip;

        return obj;
    }
    public AudioClip GetAnimationAudioClip(int listNum) {
        string resourcePath = PathData.ITEMANIMSOUND_PATH + ObjectDataManager.Instance.Object3DList[(int)listNum].AnimationSound + ".mp3";
        //Debug.Log(resourcePath);
        AudioClip obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.SOUND, resourcePath) as AudioClip;

        return obj;
    }
    public AudioClip GetBGMAudioclip(SoundDataEnum.BGM_TYPE listNum)
    {
        string resourcePath = PathData.BGM_PATH + SoundDataManager.Instance.BGMList[(int)listNum].Path + ".mp3";
        //Debug.Log(resourcePath);
        AudioClip obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.SOUND, resourcePath) as AudioClip;

        return obj;
    }

    public AudioClip GetEffectAudioclip(SoundDataEnum.EFFECT_TYPE listNum)
    {
        string resourcePath = PathData.EFFECTSOUND_PATH + SoundDataManager.Instance.EffectSoundList[(int)listNum].Path + ".mp3";
        //Debug.Log(resourcePath);
        AudioClip obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.SOUND, resourcePath) as AudioClip;

        return obj;
    }

    public AudioClip GetScriptAudioclip(int frontSub, int middleSub, int listNum) {
        string resourcePath = null;

        switch (GamedataManager.m_SpeakType) {
            case (int)VoiceManager.SpeakType.INTIMACY:
                resourcePath = PathData.SCRIPTSOUND_PATH + SoundDataManager.Instance.ScriptSoundList[frontSub].Path + (middleSub + 1).ToString() + "_" + (listNum + 1).ToString() + ".mp3";
                break;
            case (int)VoiceManager.SpeakType.CORRECTLIFE:
                resourcePath = PathData.SCRIPTSOUND_PATH + SoundDataManager.Instance.ScriptSoundList[frontSub].Path + SoundDataManager.Instance.Etiquette_SubList[middleSub - 1].Path + (listNum + 1).ToString() + ".mp3";
                break;
            case (int)VoiceManager.SpeakType.LEARNING:
                resourcePath = PathData.SCRIPTSOUND_PATH + SoundDataManager.Instance.ScriptSoundList[frontSub].Path + (middleSub + 1).ToString() + ".mp3";
                break;
        }
        
        //Debug.Log(resourcePath);
        AudioClip obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.SOUND, resourcePath) as AudioClip;

        return obj;
    }
    public AudioClip GetOnBoardAudioclip(SoundDataEnum.ONBOARD_TYPE listNum) {
        string resourcePath = PathData.ONBOARDSOUND_PATH + SoundDataManager.Instance.OnboardSoundList[(int)listNum].Path + ".mp3";
        //Debug.Log(resourcePath);
        AudioClip obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.SOUND, resourcePath) as AudioClip;

        return obj;
    }
    public AudioClip GetEtcAudioclip(SoundDataEnum.ETC_TYPE listNum) {
        string resourcePath = PathData.ETCSOUND_PATH + SoundDataManager.Instance.ETCSoundList[(int)listNum].Path + ".mp3";
        //Debug.Log(resourcePath);
        AudioClip obj = m_bundleManager.DownLoadMyAsset(AssetBundleEnum.BUNDLE_TYPE.SOUND, resourcePath) as AudioClip;

        return obj;
    }
}
